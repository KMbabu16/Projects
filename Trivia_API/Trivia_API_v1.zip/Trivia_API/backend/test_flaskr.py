import os
import unittest

from flaskr import create_app
from models import db, Question, Category
import json


class TriviaTestCase(unittest.TestCase):
    """This class represents the trivia test case"""

    def setUp(self):
        """Define test variables and initialize app."""
        self.database_name = "trivia"
        self.database_user = "postgres"
        self.database_password = "mohan"
        self.database_host = "localhost:5432"
        self.database_path = f"postgresql://{self.database_user}:{self.database_password}@{self.database_host}/{self.database_name}"

        # Create app with the test configuration
        self.app = create_app({
            "SQLALCHEMY_DATABASE_URI": self.database_path,
            "SQLALCHEMY_TRACK_MODIFICATIONS": False,
            "TESTING": True
        })
        self.client = self.app.test_client()

#        # Bind the app to the current context and create all tables
        with self.app.app_context():
            db.create_all()

    def tearDown(self):
        """Executed after each test"""
        with self.app.app_context():
            db.session.remove()
            #db.drop_all()

    """
    TODO
    Write at least one test for each test for successful operation and for expected errors.
    """
    def test_get_questions(self):
        res = self.client.get("/questions")
        data = json.loads(res.data)
        self.assertEqual(res.status_code, 200)
        self.assertEqual(data["success"], True)
        self.assertTrue(data["totalQuestions"])
        self.assertTrue(len(data["questions"]))
        self.assertTrue(data["categories"])
    def test_get_categories(self):
        res = self.client.get("/categories")
        data = json.loads(res.data)
        self.assertEqual(res.status_code, 200)
        self.assertEqual(data["success"], True)
        self.assertTrue(data["categories"])
    
    def test_delete_question(self):
        res=self.client.delete("/questions/15")
        data = res.get_json()
        self.assertEqual(res.status_code, 422)
        self.assertEqual(True, True)       

    def test_submit_question(self):
        new_question = {"question": "What is your name", "answer": "mohan", "category": 4,"difficulty":3}
        res=self.client.post("/questions",json=new_question)
        data = res.get_json()
        self.assertEqual(res.status_code, 200)
        self.assertEqual(data["success"], True)   
    def test_submit_category(self):
        new_category = {"type":"Anime"}
        res=self.client.post("/categories",json=new_category)
        data = res.get_json()
        self.assertEqual(res.status_code, 200)
        self.assertEqual(data["success"], True)   
    def test_search_question(self):
        search = {"searchTerm":"pen"}
        res=self.client.post("/questions",json=search)
        data = res.get_json()
        self.assertEqual(res.status_code, 200)
        Question_res=data["questions"]
        self.assertEqual(res.status_code, 200)
        self.assertTrue(data["questions"])
        self.assertTrue(Question_res[0]["question"])
        self.assertTrue(Question_res[0]["answer"])
        self.assertTrue(Question_res[0]["difficulty"])
        self.assertTrue(Question_res[0]["category"]) 
    def test_search_category(self):
        search = {"searchTerm":"his"}
        res=self.client.post("/categories",json=search)
        data = res.get_json()
        self.assertEqual(res.status_code, 200)
        category_res=data["category"]
        self.assertEqual(res.status_code, 200)
        self.assertTrue(data["category"])
        self.assertTrue(category_res[0]["id"])
        self.assertTrue(category_res[0]["type"])
    def test_categories_with_questions(self):
        res = self.client.get("/categories/5/questions")
        data = res.get_json()
        self.assertEqual(res.status_code, 200)
        self.assertEqual(data["success"], True)
        self.assertTrue(data["questions"])
        self.assertTrue(data["totalQuestions"])
        self.assertTrue(data["current_category"])
    def test_categories_with_questions_failure(self):
        res = self.client.get("/categories/10/questions")
        data = res.get_json()
        self.assertEqual(res.status_code, 404)
        self.assertEqual(data["success"], False)
    def test_categories_with_questions_failure2(self):
        res = self.client.get("/categories/10")
        data = res.get_json()
        self.assertEqual(res.status_code, 404)
        self.assertEqual(data["success"], False)
    def test_quizzes_next_exist(self):
        prev_question={"previousQuestions": [], "quizCategory": {"id":1,"type":"Science"}}
        res = self.client.post("/quizzes",json=prev_question)
        data = res.get_json()
        Question_res=data["question"]
        self.assertEqual(res.status_code, 200)
        self.assertTrue(data["question"])
        self.assertTrue(Question_res["question"])
        self.assertTrue(Question_res["answer"])
        self.assertTrue(Question_res["difficulty"])
        self.assertTrue(Question_res["category"])
    def test_quizzes_next_not_exist(self):
        prev_question={"previousQuestions": [], "quizCategory": {"id":999,"type":"Nala"}}
        res = self.client.post("/quizzes",json=prev_question)
        data = res.get_json()
        self.assertEqual(res.status_code, 404)
    
# Make the tests conveniently executable
if __name__ == "__main__":
    unittest.main()
